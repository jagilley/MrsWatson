var searchData=
[
  ['max',['Max',['../namespaceSteinberg.html#a0f480f7384f085c2606eff5f310ad194',1,'Steinberg']]],
  ['min',['Min',['../namespaceSteinberg.html#affba9ed0dfe13309d79094f10bbc6021',1,'Steinberg']]]
];
