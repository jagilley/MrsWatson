var searchData=
[
  ['pluginbasefwd_2eh',['pluginbasefwd.h',['../pluginbasefwd_8h.html',1,'']]]
];
