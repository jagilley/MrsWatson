var searchData=
[
  ['declare_5fclass_5fiid',['DECLARE_CLASS_IID',['../funknown_8h.html#aae92a855975a91bb846f6e0f906745f1',1,'funknown.h']]],
  ['declare_5ffunknown_5fmethods',['DECLARE_FUNKNOWN_METHODS',['../funknown_8h.html#acb6e5cc5e226c37c1fca4f5192fb80a2',1,'funknown.h']]],
  ['declare_5fuid',['DECLARE_UID',['../funknown_8h.html#a5e349c26a022f90b3562eeb32976e6ed',1,'funknown.h']]],
  ['def_5fclass_5fiid',['DEF_CLASS_IID',['../funknown_8h.html#a8999be9dadfd41e1f563866e01e94d1c',1,'funknown.h']]],
  ['delegate_5frefcount',['DELEGATE_REFCOUNT',['../funknown_8h.html#a6d9d411a27dcc158df8ff1f5e73510d0',1,'funknown.h']]]
];
