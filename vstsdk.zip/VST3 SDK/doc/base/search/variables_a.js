var searchData=
[
  ['ptr',['ptr',['../classSteinberg_1_1IPtr.html#a7c145f458643ff993b929f236d4a2ac0',1,'Steinberg::IPtr']]]
];
