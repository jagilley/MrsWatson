var searchData=
[
  ['smtg_5falways_5finline',['SMTG_ALWAYS_INLINE',['../ftypes_8h.html#a3df4ece706682a504fa3d08c3b0a04a4',1,'ftypes.h']]],
  ['smtg_5fnever_5finline',['SMTG_NEVER_INLINE',['../ftypes_8h.html#af946828d11bb0aed103fac1d14b4b1b8',1,'ftypes.h']]],
  ['str',['STR',['../fstrdefs_8h.html#a18d295a837ac71add5578860b55e5502',1,'fstrdefs.h']]],
  ['str16',['STR16',['../fstrdefs_8h.html#a826c07705e0d6242387611986d74ee48',1,'fstrdefs.h']]],
  ['str16buffersize',['str16BufferSize',['../fstrdefs_8h.html#ab60e7beaa39f0257d103524ccbb7aa9e',1,'fstrdefs.h']]],
  ['str8buffersize',['str8BufferSize',['../fstrdefs_8h.html#aa2da887b221541aae95dc720e91f1563',1,'fstrdefs.h']]],
  ['swap_5f16',['SWAP_16',['../ftypes_8h.html#a178e2230dac3adf497d06c6f42abccad',1,'ftypes.h']]],
  ['swap_5f32',['SWAP_32',['../ftypes_8h.html#ad0de6cd6cef290e9609feccdf002f51c',1,'ftypes.h']]],
  ['swap_5f64',['SWAP_64',['../ftypes_8h.html#ae7ff9262ec2cb91d49035bffbea62625',1,'ftypes.h']]]
];
