var searchData=
[
  ['kbigendian',['kBigEndian',['../fplatform_8h.html#a59154ea8599c8d0e7187be1c42889675',1,'fplatform.h']]],
  ['klittleendian',['kLittleEndian',['../fplatform_8h.html#abfa3c6c92ac4ce1ce65133b421fee2fe',1,'fplatform.h']]]
];
